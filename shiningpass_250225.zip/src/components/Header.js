import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function Header() {
    return (
      <header className="site-header">
        <h1>ShiningPass</h1>

        <Link
          to="/login"
          className="btn-login"
        >
          로그인
        </Link>
      </header>
    );
}

export default Header;
